#My first Python Script
print('Hello World')
print("I Love Python")
#Variables and Data types in Python
"""
Strings
Numeric: int, float, complex
Sequence: list, tuple, range
Mapping datatype: dict
Boolean: True or False
"""
#Create a variable
my_str = "Programmer"
print(my_str)
num = 2.5677
print(type(num))
#Creating a list of numbers and some Operations.
numbers = [1, 2, 3, 4, 5]
# Print the list
print(numbers)
# Get the length of the list
print(len(numbers))
#Accessing Elements(Value 4)
print(numbers[3])
# Add a number to the list
numbers.append(6)
#Replace a value with another
numbers[0] = 7
print(numbers)
# Remove a number from the list
numbers.remove(3)
# Sort the listnumbers.sort()
# Print the sorted list
for x in numbers:
	print(x)

#Tuples
""" Tuples are immutable and so can enable us store data that shouldn't be changed"""
tuple_1 = ("apple", "banana", "cherry")
# Print the tuple
print(tuple_1)
# Check the length of the tuple
print(len(tuple_1))
# Access an element in the tuple
print(tuple_1[2])
# Change an element in the tuple (not possible)
#tuple_1[2] = "orange"
# Add an element to the tuple (not possible)
#tuple_1.append("orange")
# Delete an element from the tuple (not possible)
#del tuple_1[2]
# Check if an element is in the tuple
print("apple" in tuple_1)
# Iterate over the tuple
for element in tuple_1:
	print(element)

#Sets
"""Sets are unordered and don't allow duplicates"""
set_one = {"apple", "banana", "cherry"}
# Print the set
print(set_one)# Check the length of the set
print(len(set_one))
# Add an element to the set
set_one.add("orange")
#Add an element that already exists
set_one.add("apple")
print(set_one)
# Remove an element from the set
set_one.remove("banana")
# Check if an element is in the set
print("apple" in set_one)
# Iterate over the set
for element in set_one:
	print(element)
#Adding two sets
set_two = {"berries", "pineapple", "mangoes"}

result = set_one | set_two

print(result)